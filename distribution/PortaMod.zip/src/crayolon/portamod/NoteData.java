package crayolon.portamod;
public class NoteData {
  public int currentseq, seqlength, currentrow, currentrealrow, channel, note, inst, vol, effect, effparam;
  public long timestamp;  
}