package crayolon.portamod;
public class CellContent {
  public int seqlength, channel;
  public String note, inst, vol, effect, effparam;
}