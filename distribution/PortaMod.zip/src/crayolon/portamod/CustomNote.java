package crayolon.portamod;

public class CustomNote {
  public int channel, note, inst, vol, effect, effparam;  
}